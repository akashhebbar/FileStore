from rest_framework import serializers
from .models import FileDetails
from .models import PDF
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from .models import User
class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model = FileDetails
        fields=['name', 'type', ]
        


class PDFSerializer(serializers.ModelSerializer):
    class Meta:
        model = PDF
        fields = ('id', 'file', 'created_at','user_id','file_type', 'file_name')
        
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'password','phone','address','name')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User(
            username=validated_data['username'],
            name=validated_data['name'],
            phone=validated_data['phone'],
            address=validated_data['address']
        )
        user.set_password(validated_data['password'])
        user.save()
        return user

    # def create(self, validated_data):
    #     user = User.objects.create(
    #         username=validated_data['username'],
    #     )
    #     user.set_password(validated_data['password'])
    #     user.save()
    #     return user