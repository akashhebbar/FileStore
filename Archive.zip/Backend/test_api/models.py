from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from django.conf import settings
# Create your models here.
class FileDetails(models.Model):
    name= models.CharField(max_length=50)
    type=models.CharField(max_length=50)
    class Meta:
        db_table = 'file_details'
    
    def __str__(self):
        return  self.name + ' ' + self.type
    

    
class PDF(models.Model):
    file = models.FileField(upload_to='pdfs/')
    created_at = models.DateTimeField(auto_now_add=True)
    file_type = models.CharField(max_length=255, blank=True)
    user_id=models.CharField(max_length=50)
    file_name=models.CharField(max_length=50)
    class Meta:
        db_table = 'pdf'
    def __str__(self):
        return  self.user_id
    
class User(AbstractUser):
    username = models.CharField(max_length=255,unique=True)
    password = models.CharField(max_length=255)
    # email = models.CharField(max_length=255)
    phone = models.IntegerField(null=True)
    address = models.CharField(max_length=500)
    name=models.CharField(max_length=100)
    # REQUIRED_FIELDS = ['username']