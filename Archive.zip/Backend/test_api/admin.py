from django.contrib import admin
from .models import FileDetails,PDF
# Register your models here.

admin.site.register(FileDetails)
admin.site.register(PDF)