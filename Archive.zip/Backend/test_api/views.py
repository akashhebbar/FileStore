from django.shortcuts import render
from django.http import JsonResponse
from .models import FileDetails
from .serializers import BookSerializer
import json
import os
from django.db.models import Count
from django.conf import settings
from django.shortcuts import get_object_or_404
from django.core.exceptions import ValidationError
from rest_framework.decorators import api_view
from django.db import connection
from django.http import HttpResponse,Http404
from rest_framework.views import APIView
from rest_framework import status
from .serializers import PDFSerializer
from rest_framework.response import Response
from rest_framework import generics
from .models import PDF,User
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import UserSerializer
from rest_framework.authentication import TokenAuthentication
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.authentication import SessionAuthentication
from rest_framework import generics

def get_file_type(file_path):
    extension = os.path.splitext(file_path)[1].lower()
    if extension == '.pdf':
        return 'application/pdf'
    elif extension == '.doc' or extension == '.docx':
        return 'application/msword'
    elif extension == '.xls' or extension == '.xlsx':
        return 'application/vnd.ms-excel'
    elif extension == '.txt':
        return 'text/plain'
    elif extension == '.csv':
        return 'text/csv'
    else:
        return None
       
class UploadPDF(APIView):
    def post(self, request, format=None):
        uploaded_file = request.FILES['file']
        user_id = request.data.get('user_id')
        file_name = request.data.get('file_name')
        file_type = get_file_type(uploaded_file.name)
        # serializer = PDFSerializer(data=request.data)
        uploaded_file_obj = PDF(file=uploaded_file,user_id=user_id, file_type=file_type,file_name=file_name)
        try:
            uploaded_file_obj.full_clean()
            uploaded_file_obj.save()
        except ValidationError as e:
            return JsonResponse({'error': str(e)}, status=400)

        return JsonResponse({'success': 'File uploaded successfully.'})

        
class PDFListCreate(generics.ListAPIView):
    print("here",flush=True)
    authentication_classes = [JWTAuthentication, SessionAuthentication]
    permission_classes = [IsAuthenticated]
    queryset = PDF.objects.all()
    serializer_class = PDFSerializer
    
def download_file(request, file_id):
    try:
        pdf_file = PDF.objects.get(id=file_id)
        file_path = os.path.join(settings.MEDIA_ROOT, str(pdf_file.file))
        with open(file_path, 'rb') as f:
            response = HttpResponse(f.read(), content_type='application/pdf')
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    except PDF.DoesNotExist:
        raise Http404
    
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        refresh = RefreshToken.for_user(user)
        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'status':200,
            'success':True,
            'data':"User created successfully"
        })

class UserDetailView(generics.RetrieveUpdateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user_id = kwargs.get('pk')
        user = get_object_or_404(User, id=user_id)
        serializer = UserSerializer(user)
        return Response(serializer.data)

    def put(self, request, *args, **kwargs):
        user_id = kwargs.get('pk')
        user = get_object_or_404(User, id=user_id)
        serializer = UserSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)

class LoginView(generics.CreateAPIView):
    queryset = User.objects.all()

    def post(self, request, *args, **kwargs):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'username':str(username),
                'user_id':str(user.id),
                'name':str(user.name),
                'access': str(refresh.access_token),
                'status':200,
                'data':"Login successfully",
            'success':True
            })
        else:
            return Response({'error': 'Invalid credentials'})
        
@api_view(['GET'])
def file_stats(request):
    num_files = PDF.objects.count()
    file_types = PDF.objects.values('file_type').annotate(count=Count('id'))
    user_files = PDF.objects.values('user_id').annotate(count=Count('id'))

    stats = {
        'total_files': num_files,
        'file_types': {t['file_type']: t['count'] for t in file_types},
        'user_files': {u['user_id']: u['count'] for u in user_files}
    }

    return Response(stats)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken

class RefreshTokenView(APIView):
    def post(self, request, *args, **kwargs):
        refresh_token = request.data.get('refresh_token')
        if refresh_token:
            try:
                refresh = RefreshToken(refresh_token)
                access_token = str(refresh.access_token)
                return Response({
                    'access_token': access_token,
                }, status=status.HTTP_200_OK)
            except:
                return Response({
                    'error': 'Invalid refresh token',
                }, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({
                'error': 'Refresh token not provided',
            }, status=status.HTTP_400_BAD_REQUEST)