import { Routes, Route } from "react-router-dom";
import SignUp from "./SignUpForm";
import Login from "./Login";
import DashBoard from "./DashBoard";
import Portal from "./Portal";
import Profile from "./Profile";
function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/dashboard" element={<DashBoard />} />
        <Route path="/portal" element={<Portal />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
    </div>
  );
}

export default App;
