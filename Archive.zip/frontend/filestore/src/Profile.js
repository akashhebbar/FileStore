import { useNavigate } from "react-router-dom";
import * as React from "react";
import {useState,useEffect}from "react";
import Avatar from "@mui/material/Avatar";
import Cookies from "js-cookie";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import axios from "axios";
function Copyright(props) {
  return (
    <Typography
      variant="body2"
      color="text.secondary"
      align="center"
      {...props}
    >
      {"Copyright © "}
      <Link color="inherit" href="">
        File Store
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

const theme = createTheme();

export default function App() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({
    name: '',
    address: '',
    phone: '',
  });

  function sendAuthenticatedRequest(endpoint, method, data = {}, config = {}) {
    const accessToken = Cookies.get("access_token");
    const refreshToken = Cookies.get("refresh_token");
  
    return axios({
      method: method,
      url: endpoint,
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      data: data,
      ...config,
    })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        if (error.response && error.response.status === 401) {
          // Access token has expired, try to get a new one
          return axios({
            method: "POST",
            url: `http://localhost:8000/refresh-token/`,
            headers: {
              "Content-Type": "application/json",
            },
            data: {
              refresh_token: refreshToken,
            },
          })
            .then((response) => {
              // Update access token in cookies
              const newAccessToken = response.data.access_token;
              Cookies.set("access_token", newAccessToken);
  
              // Retry original request with new access token
              return axios({
                method: method,
                url: endpoint,
                headers: {
                  Authorization: `Bearer ${newAccessToken}`,
                },
                data: data,
                ...config,
              }).then((response) => {
                return response.data;
              });
            })
            .catch((error) => {
              navigate("/")
              throw new Error("Failed to refresh access token");
            });
        } else {
          throw error;
        }
      });
  }
  
  useEffect(() => {

    sendAuthenticatedRequest(`http://localhost:8000/users/${Cookies.get('user_id')}`, "GET")
    .then((response) => {
      const { address,id, name, phone } = response;
      setUserData({
        address,
        name,
        phone
      });
    })
    
    .catch((error) => {
      // Handle error
    });

  }, []);



  const handleSubmit = (event) => {
    sendAuthenticatedRequest(`http://localhost:8000/users/${Cookies.get('user_id')}/`, "PUT",userData)
    .then((response) => {
      const { address,id, name, phone } = response;
      setUserData({
        address,
        name,
        phone
      });
    })
  };
  const handleLogout = () => {
    Cookies.remove('access_token');
    Cookies.remove('user_id');
    Cookies.remove('username');
    Cookies.remove('username');
    navigate("/");
  };

  console.log("userData",userData)
  return (
    <ThemeProvider theme={theme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            {Cookies.get("username")}
          </Typography>
          <Box
            component="form"
            onSubmit={handleSubmit}
            noValidate
            sx={{ mt: 1 }}
          >
             <TextField
              margin="normal"
              required
              fullWidth
               onChange={(event) => setUserData({ ...userData, name: event.target.value })}
              value={userData.name}
              id="name"
              label="Name"
              name="name"
              autoComplete="name"
              autoFocus
            />

            <TextField
              margin="normal"
              required
              fullWidth
              onChange={(event) => setUserData({ ...userData, phone: event.target.value })}
              value={userData.phone}
              name="phone"
              label="Phone"
              type="text"
              id="phone"
              autoComplete="current-password"
            />
             <TextField
              margin="normal"
              required
              fullWidth
              onChange={(event) => setUserData({ ...userData, address: event.target.value })}
              value={userData.address}
              name="address"
              label="Address"
              type="text"
              id="address"
              autoComplete="current-password"
            />
            <Button
              type="submit"

              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Update
            </Button>
            <Button
              type="button"
              onClick={handleLogout}
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Logout
            </Button>
            <Grid container>
              <Grid item>
                <Link href="/dashboard" variant="body2">
                  {"Go To Dashboard"}
                </Link>

              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
    </ThemeProvider>
  );
}
