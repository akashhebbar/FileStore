import * as React from "react";
import { useEffect, useState } from "react";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Menu from "@mui/material/Menu";
import Cookies from "js-cookie";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import "./index.css";
import FolderIcon from '@mui/icons-material/Folder';
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

const pages = ["upload"];
const portal_pages = [ "portal"];
const settings = ["Profile", "Account", "Dashboard", "Logout"];

function DashBoard() {
  const navigate = useNavigate();
  const [open, setOpen] = React.useState(false);
  const [loadTable,setLoadTable]= React.useState(false);
  const [fileData, setFileData] = React.useState([]);
  const [fileType, setFileType] = React.useState([]);
  const [fileDataDisplay, setFileDataDisplay] = React.useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [select_filename, setSelect_filename] = useState("null");
  const handleClickOpen = (page) => {
  setOpen(true); 
  };
  const handleClickOpenPortal = () => {
    navigate("/portal") 
  };

  const bull = (
    <Box
      component="span"
      sx={{ display: 'inline-block', mx: '2px', transform: 'scale(0.8)' }}
    >
      •
    </Box>
  );
  
  useEffect(() => {
    try {
      axios({
        method: "GET",
        withCredentials: true,
        url: `http://localhost:8000/status/`,
        headers: {
          Authorization: `Bearer ${Cookies.get("access_token")}`,
        },
        data: {},
      }).then((response) => {
        setFileData(response.data.total_files)
        console.log("response",response.data)
        const userFilesArray = Object.entries(response.data.user_files).map(([key, value]) => {
          return { userId: key, numFiles: value };
      });
      const userFileTypeArray = Object.entries(response.data.file_types).map(([key, value]) => {
        return { type: key, count: value };
      });
      
      setFileType(userFileTypeArray)
        setFileDataDisplay(userFilesArray ) 

      });
    } catch (error) {
      console.error(error);
      // setError("Failed to register user");
    }
  }, [])

  console.log("fileData", fileData);
  return (
    <>
      <AppBar
        sx={{
          display: { bgcolor: "green" },
          mr: 1,
        }}
        position="static"
      >
        <Container maxWidth="xl">
          <Toolbar disableGutters>
          <FolderIcon sx={{ display: { xs: "flex", md: "none" }, mr: 1 ,color:"white"}} />
            <Typography
              variant="h6"
              noWrap
              component="a"
              href="/dashboard"
              sx={{
                color:"white",
                mr: 2,
                display: { xs: "none", md: "flex" },
                fontFamily: "monospace",
                fontWeight: 700,
                letterSpacing: ".3rem",
            
                textDecoration: "none",
              }}
            >
              FILE STORE
            </Typography>

            <Typography
              variant="h5"
              noWrap
              component="a"
              href=""
              sx={{
                mr: 2,
                display: { xs: "flex", md: "none" },
                flexGrow: 1,
                fontFamily: "monospace",
                fontWeight: 700,
                marginLeft: "20px",
                letterSpacing: ".3rem",
                color:"white",
                textDecoration: "none",
              }}
            >
              FILE STORE
            </Typography>
            <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } , marginLeft:"20px", color:"white"}}>
              {pages.map((page) => (
                <Button
                  key={page}
                  onClick={handleClickOpen}
                  sx={{ my: 2, color: "white", display: "block" }}
                >
                  {page}
                </Button>
              ))}
            </Box>
            <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "flex" } , marginLeft:"-980px", color:"white"}}>
              {portal_pages.map((page) => (
                <Button
                  key={page}
                  onClick={handleClickOpenPortal}
                  sx={{ my: 2, color: "white", display: "block" }}
                >
                  {page}
                </Button>
              ))}
            </Box>

            <Box sx={{ flexGrow: 0 }}>
              <Tooltip title="Open settings">
                <IconButton sx={{ p: 0 }}>
                  <Avatar alt="Remy Sharp" src="/static/images/avatar/2.jpg" />
                </IconButton>
              </Tooltip>
              <Menu
                sx={{ mt: "45px" }}
                id="menu-appbar"
                //   anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
              >
                {settings.map((setting) => (
                  <MenuItem key={setting}>
                    <Typography textAlign="center">{setting}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
      <div>
      <Card sx={{ minWidth: 275 }}>
           <CardContent>
             <Typography variant="h5" component="div">
             Total number of files upload:{fileData}
             </Typography>
           </CardContent>
         </Card>
         {fileType?.map(item =>
           <Card sx={{ minWidth: 275 }}>
           <CardContent>
             <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
             File Types: {item.type}
             </Typography>
             <Typography variant="h5" component="div">
             Count:{item.count}
             </Typography>
           </CardContent>
         </Card>
          
          
          
          
          )}

        {fileDataDisplay?.map(item =>
           <Card sx={{ minWidth: 275 }}>
           <CardContent>
             <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
             User ID: {item.userId}
             </Typography>
             <Typography variant="h5" component="div">
             Number of files upload:{item.numFiles}
             </Typography>
           </CardContent>
         </Card>
          )}
     
      </div>
    </>
  );
}
export default DashBoard;
