import Swal from 'sweetalert2'
import { useNavigate } from "react-router-dom";
import * as React from "react";
import Cookies from "js-cookie";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import axios from "axios";
function Copyright(props) {
  return (
    <Typography
      variant="body2"
      color="text.secondary"
      align="center"
      {...props}
    >
      {"Copyright © "}
      <Link color="inherit" href="">
        FileStore
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

const theme = createTheme();

export default function App() {
  const navigate = useNavigate();
  const handleSubmit = (event) => {
    event.preventDefault();
      const data = new FormData(event.currentTarget);
    console.log("here");
    const isValidEmail = (email) => {
      const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
      return emailRegex.test(email);
    }
    const isValid = isValidEmail(data.get("email"));
    if (!isValid){
      Swal.fire({
        title: "Please enter valid email address",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else if(data.get("password") == ""){
      Swal.fire({
        title: "Please enter valid password",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else if(data.get("password").length <8 ){
      Swal.fire({
        title: "Password must be minimum 8 characters",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else{
      
      try {
        axios({
          method: "POST",
          withCredentials: true,
          url: `http://localhost:8000/login/`,
          headers: {},
          data: {
            password: data.get("password"),
            username: data.get("email"),
          },
        }).then((response) => {
          if (response.data.status == 200) {
            Swal.fire({
              title: `Welcome  ${response.data.name}`,
              icon: 'success',
              showCancelButton: false,
              confirmButtonColor: '#a5dc86',
            }).then((result) => {
              if (result.isConfirmed) { 
            Cookies.set("access_token", response.data.access);
            Cookies.set("refresh_token", response.data.refresh);
            Cookies.set("username", response.data.username);
            Cookies.set("user_id", response.data.user_id);
            Cookies.set("name", response.data.name);
            navigate("/dashboard");
              }
            })
           
          }
          else
          {
            Swal.fire({
              title: response.data.error,
              icon: 'error',
              showCancelButton: false,
              confirmButtonColor: '#f27474',
            })
          }
          
          
          console.log("response", response.data.data);
          console.log("responseresponse", response);
        });
      } catch (error) {
        console.error(error);
        // setError("Failed to register user");
      }

    }

    
  };
  const handleClick = () => {
    navigate("/signup");
  };
 
  return (
    <ThemeProvider theme={theme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Sign in
          </Typography>
          <Box
            component="form"
            onSubmit={handleSubmit}
            noValidate
            sx={{ mt: 1 }}
          >
            <TextField
              margin="normal"
              required
              fullWidth
              id="email"
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign In
            </Button>
            <Grid container>

              <Grid onClick={handleClick} item>
                <Link  variant="body2">
                  {"Don't have an account? Sign Up"}
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Box>
        <Copyright sx={{ mt: 8, mb: 4 }} />
      </Container>
    </ThemeProvider>
  );
}
