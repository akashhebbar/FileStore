import * as React from "react";
import Swal from 'sweetalert2'
import { useEffect, useState } from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import Cookies from "js-cookie";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import AdbIcon from "@mui/icons-material/Adb";
import MaterialTable from "material-table";
import Button from "@mui/material/Button";
import "./index.css";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import FolderIcon from '@mui/icons-material/Folder';
import axios from "axios";
import { useNavigate } from "react-router-dom";
const pages = ["upload"];
const portal_pages = [ "portal"];
const settings = ["Profile", "Account", "Dashboard", "Logout"];

function DashBoard() {

  const navigate = useNavigate();
  const [open, setOpen] = React.useState(false);
  const [loadTable,setLoadTable]= React.useState(false);
  const [fileData, setFileData] = React.useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [select_filename, setSelect_filename] = useState("");
  const handleClickOpen = (page) => {
    setOpen(true);
  };
  const handleClickOpenPortal = () => {
    navigate("/portal") 
  };

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };
  const handleClose = () => {
    handleSubmit();
  };

  const goToProfile = () => {
    navigate("/profile")
  };
  const handleSubmit = () => {
    // event.preventDefault();
    if (select_filename =="" ||  Cookies.get("user_id") ==""){
      setOpen(false);
      Swal.fire({
        title: "Please enter file name",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else
    {
    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("user_id", Cookies.get("user_id"));
    formData.append("file_name", select_filename);

    axios
      .post("http://localhost:8000/pdf/", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((response) => {
        setLoadTable(!loadTable)
        
        Swal.fire({
          title: response.data.success,
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#a5dc86',
        })

        console.log("response,",response.data);
        setOpen(false);
      })
      .catch((error) => {
        console.log(error);
      });
    }
  };

  const columns = [
    { title: "ID", field: "id" },   
    { title: "Created at", field: "created_at" },
    { title: "File name", field: "file_name" ,render:rowData=><a target="_blank" href={`http://localhost:8000/download-file/${rowData.id}`}>{rowData.file_name}</a>},
    { title: "File type", field: "file_type" },
    { title: "User ID", field: "user_id" },

    // { title: "File", field: "file" },
  ];
  function sendAuthenticatedRequest(endpoint, method, data = {}, config = {}) {
    const accessToken = Cookies.get("access_token");
    const refreshToken = Cookies.get("refresh_token");
    return axios({
      method: method,
      url: endpoint,
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      data: data,
      ...config,
    })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        if (error.response && error.response.status === 401) {
          return axios({
            method: "POST",
            url: `http://localhost:8000/refresh-token/`,
            headers: {
              "Content-Type": "application/json",
            },
            data: {
              refresh_token: refreshToken,
            },
          })
            .then((response) => {
              const newAccessToken = response.data.access_token;
              Cookies.set("access_token", newAccessToken);
              return axios({
                method: method,
                url: endpoint,
                headers: {
                  Authorization: `Bearer ${newAccessToken}`,
                },
                data: data,
                ...config,
              }).then((response) => {
                return response.data;
              });
            })
            .catch((error) => {
              navigate("/")
              throw new Error("Failed to refresh access token");
            });
        } else {
          throw error;
        }
      });
  }
  

  useEffect(() => {

    sendAuthenticatedRequest("http://localhost:8000/getpdf/", "GET")
  .then((response) => {
    console.log("response",response)
    // Handle successful response
    setFileData(response);
  })
  .catch((error) => {
    // Handle error
  });
  }, [loadTable]);

  console.log("fileData", fileData);
  return (
    <>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Select any file</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            id="file_name"
            onChange={(e)=>setSelect_filename(e.target.value)}
            label="Enter file name"
            type="text"
            fullWidth
            variant="standard"
          />
          <input
            style={{ paddingTop: "20px" }}
            type="file"
            accept=".pdf,.xlsx,.xls,.csv"
            onChange={handleFileChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleClose}>Upload</Button>
        </DialogActions>
      </Dialog>
      <AppBar
        sx={{
          display: { bgcolor: "green" },
          mr: 1,
        }}
        position="static"
      >
        <Container maxWidth="xl">
          <Toolbar disableGutters>
          <FolderIcon sx={{ display: { xs: "flex", md: "none" }, mr: 1 ,color:"white"}} />
            <Typography
              variant="h6"
              noWrap
              component="a"
              href="/"
              sx={{
                color:"white",
                mr: 2,
                display: { xs: "none", md: "flex" },
                fontFamily: "monospace",
                fontWeight: 700,
                letterSpacing: ".3rem",
            
                textDecoration: "none",
              }}
            >
              FILE STORE
            </Typography>

            <Typography
              variant="h5"
              noWrap
              component="a"
              href=""
              sx={{
                mr: 2,
                display: { xs: "flex", md: "none" },
                flexGrow: 1,
                fontFamily: "monospace",
                fontWeight: 700,
                marginLeft: "20px",
                letterSpacing: ".3rem",
                color:"white",
                textDecoration: "none",
              }}
            >
              FILE STORE
            </Typography>
            <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } , marginLeft:"20px", color:"white"}}>
              {pages.map((page) => (
                <Button
                  key={page}
                  onClick={handleClickOpen}
                  sx={{ my: 2, color: "white", display: "block" }}
                >
                  {page}
                </Button>
              ))}
            </Box>
            <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "flex" } , marginLeft:"-980px", color:"white"}}>
              {portal_pages.map((page) => (
                <Button
                  key={page}
                  onClick={handleClickOpenPortal}
                  sx={{ my: 2, color: "white", display: "block" }}
                >
                  {page}
                </Button>
              ))}
            </Box>

            <Box sx={{ flexGrow: 0 }} onClick={goToProfile}>
              <Tooltip title="Profile">
                <IconButton sx={{ p: 0 }}>
                  <Avatar alt="Remy Sharp" src="/static/images/avatar/2.jpg" />
                </IconButton>
              </Tooltip>
              <Menu
                sx={{ mt: "45px" }}
                id="menu-appbar"
                //   anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
              >
                {settings.map((setting) => (
                  <MenuItem key={setting}>
                    <Typography textAlign="center">{setting}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
      <div>
        <MaterialTable title="Uploaded Files" columns={columns} data={fileData} />
      </div>
    </>
  );
}
export default DashBoard;
