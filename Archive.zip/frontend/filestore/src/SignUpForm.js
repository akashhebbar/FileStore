import Swal from 'sweetalert2'
import { useNavigate } from "react-router-dom";
import * as React from "react";
import Avatar from "@mui/material/Avatar";
import Cookies from "js-cookie";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import axios from "axios";
function Copyright(props) {
  return (
    <Typography
      variant="body2"
      color="text.secondary"
      align="center"
      {...props}
    >
      {"Copyright © "}
      <Link color="inherit" href="https://mui.com/">
        Your Website
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

const theme = createTheme();

export default function App() {
  const navigate = useNavigate();
  const handleSubmit = (event) => {
    console.log("here");
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const isValidEmail = (email) => {
      const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
      return emailRegex.test(email);
    }
    const isValidNumber = (number) => {
      const numberRegex = /^\d{10}$/;
      return numberRegex.test(number);
    }
    const isValidMobileNumber = isValidNumber(data.get("phone"));    
    const isValid = isValidEmail(data.get("email"));
     if(data.get("name") == ""){
      Swal.fire({
        title: "Please enter valid name",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else if (!isValid){
      Swal.fire({
        title: "Please enter valid email address",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else if(data.get("password") == ""){
      Swal.fire({
        title: "Please enter valid password",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else if(data.get("password").length <8 ){
      Swal.fire({
        title: "Password must be minimum 8 characters",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else if(data.get("address")== ""){
      Swal.fire({
        title: "Please enter valid address",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else if(!isValidMobileNumber){
      Swal.fire({
        title: "Please enter valid mobile number",
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
    }
    else{
    try {
      axios({
        method: "POST",
        withCredentials: true,
        url: `http://localhost:8000/register/`,
        headers: {},
        data: {
          password: data.get("password"),
          username: data.get("email"),
          name: data.get("name"),
          phone: data.get("phone"),
          address: data.get("address"),
        },
      }).then((response) => {
        if (response.data.success) {
          Swal.fire({
            title: `${response.data.data}`,
            icon: 'success',
            showCancelButton: false,
            confirmButtonColor: '#a5dc86',
          }).then((result) => {
            if (result.isConfirmed) { 
              navigate("/");
            }
          })
         
        }
        else
        {
          Swal.fire({
            title: response.data.data,
            icon: 'error',
            showCancelButton: false,
            confirmButtonColor: '#f27474',
          })
        }
      });
    } catch (error) {
      
      console.error(error);
      Swal.fire({
        title: error.data.data,
        icon: 'error',
        showCancelButton: false,
        confirmButtonColor: '#f27474',
      })
      // setError("Failed to register user");
    }
  }
  };
  const handleClick = () => {
    navigate("/signup");
  };

  return (
    <ThemeProvider theme={theme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Sign Up
          </Typography>
          <Box
            component="form"
            onSubmit={handleSubmit}
            noValidate
            sx={{ mt: 1 }}
          >
             <TextField
              margin="normal"
              required
              fullWidth
              id="name"
              label="Name"
              name="name"
              autoComplete="name"
              autoFocus
            />
            <TextField
              margin="normal"
              required
              fullWidth
              id="email"
              label="Email Address"
              name="email"
              autoComplete="email"
              
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="phone"
              label="Phone"
              type="text"
              id="phone"
              autoComplete="current-password"
            />
             <TextField
              margin="normal"
              required
              fullWidth
              name="address"
              label="Address"
              type="text"
              id="address"
              autoComplete="current-password"
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign In
            </Button>
            <Grid container>
              <Grid item>
                <Link href="#" variant="body2">
                  {"Already have an account? Sign In"}
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
    </ThemeProvider>
  );
}
